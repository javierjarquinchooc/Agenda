package com.example.javier.agenda;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    Integer i=0;
    EditText nombre,apell,direc,nume,correo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        nombre = (EditText) findViewById(R.id.editText);
        apell = (EditText) findViewById(R.id.editText2);
        direc = (EditText) findViewById(R.id.editText3);
        nume = (EditText) findViewById(R.id.editText4);
        correo = (EditText) findViewById(R.id.editText6);

    }


    public void cance(View view) {
        Intent regrosig = new Intent(this,MainActivity.class);

        startActivity(regrosig);
    }

    public void onClick(View view) {
        registro();
    }

    public void registro() {
        Coneccion con = new Coneccion(this,"registrar",null,1);
        SQLiteDatabase db = con.getWritableDatabase();
        ContentValues nuevo = new ContentValues();


        nuevo.put(con.camp_Nom,nombre.getText().toString());
        nuevo.put(con.camp_Apell,apell.getText().toString());
        nuevo.put(con.camp_Dire,direc.getText().toString());
        nuevo.put(con.camp_Nume,nume.getText().toString());
        nuevo.put(con.camp_Core,correo.getText().toString());
        Long resul=db.insert(con.Tabla,null,nuevo);
        Toast.makeText(getApplicationContext(),""+nuevo,Toast.LENGTH_SHORT).show();
        i++;
    }
}
