package com.example.javier.agenda;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {
Spinner carga;
TextView id,nombre,apellido,direc,tele,correo;
EditText ide,nombree,apellidoe,direce,telee,correoe;
    String idt =null ;
ArrayList<String> lista;
ArrayList<datos> listausu;
    Coneccion con ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        con=new Coneccion(getApplicationContext(),"registrar",null,1);

    carga = (Spinner) findViewById(R.id.spinner);
    id =(TextView) findViewById(R.id.textView4);
        nombre =(TextView) findViewById(R.id.textView5);
        apellido =(TextView) findViewById(R.id.textView6);
        direc =(TextView) findViewById(R.id.textView7);
        tele =(TextView) findViewById(R.id.textView8);
        correo =(TextView) findViewById(R.id.textView9);

        nombree = (EditText) findViewById(R.id.editText9);
        apellidoe = (EditText) findViewById(R.id.editText10);
        direce = (EditText) findViewById(R.id.editText11);
        telee = (EditText) findViewById(R.id.editText12);
        correoe = (EditText) findViewById(R.id.editText13);


        id.setText("ID : ");
        nombre.setText("NOMBRE : ");
        apellido.setText("APELLIDO : ");
        direc.setText("DIRECCION : ");
        tele.setText("TELEFONO : ");
        correo.setText("CORREO : ");

consultar();

      ArrayAdapter as = new ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,lista);
      carga.setAdapter(as);
     carga.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

         @Override
         public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
             if (i!=0){
                idt= listausu.get(i-1).getId();
                 id.setText("ID : "+idt);
                 nombree.setText(listausu.get(i-1).getNo().toString());
                 apellidoe.setText(listausu.get(i-1).getApe().toString());
                 direce.setText(listausu.get(i-1).getDire());
                 telee.setText(listausu.get(i-1).getNume().toString());
                 correoe.setText(listausu.get(i-1).getCore());

             }else{
                 id.setText("ID : ");
                 nombree.setText("");
                 apellidoe.setText("");
                 direce.setText("");
                 telee.setText("");
                 correoe.setText("");
             }
         }

         @Override
         public void onNothingSelected(AdapterView<?> adapterView) {

         }
     });
    }

    private void consultar() {
        SQLiteDatabase db = con.getReadableDatabase();
        datos nue=null;
        listausu = new ArrayList<datos>();
        Cursor cursor =db.rawQuery("SELECT * FROM "+con.Tabla,null);
        while (cursor.moveToNext()){

            nue = new datos();
            nue.setId(cursor.getString(0));
            nue.setNo(cursor.getString(1));
            nue.setApe(cursor.getString(2));
            nue.setDire(cursor.getString(3));
            nue.setNume(cursor.getInt(4));
            nue.setCore(cursor.getString(5));
            listausu.add(nue);
        }
        obtener();
    }

    private void obtener() {
        lista = new ArrayList<String>();
        lista.add("Seleccione");
        for (int i= 0;i<listausu.size();i++){

            lista.add(listausu.get(i).getId()+" - "+listausu.get(i).getNo()+" "+listausu.get(i).getApe());
        }
    }

    public void onClick(View view) {
        Intent nuevo = null;
        switch (view.getId()){
            case R.id.button3:
                nuevo = new  Intent(Main3Activity.this,MainActivity.class);
                startActivity(nuevo);
                break;
            case R.id.button4:
eliminar();
recreate();
                break;

            case R.id.button5:
                actualizar();
                recreate();
                break;

        }

    }

    private void eliminar() {
        SQLiteDatabase db = con.getWritableDatabase();
        String[] parametros ={ idt};
        db.delete(con.Tabla, "id=?", parametros);
        Toast.makeText(getApplicationContext(),"Se Elimino Corectamente",Toast.LENGTH_LONG).show();
        db.close();
    }

    private void actualizar() {
        SQLiteDatabase db = con.getWritableDatabase();
        ContentValues up = new ContentValues();
         String[] parametros ={ idt};

        up.put(con.camp_Nom,nombree.getText().toString());
        up.put(con.camp_Apell,apellidoe.getText().toString());
        up.put(con.camp_Dire,direce.getText().toString());
        up.put(con.camp_Nume,telee.getText().toString());
        up.put(con.camp_Core,correoe.getText().toString());
        db.update(con.Tabla,up,"id=?",parametros);
        Toast.makeText(getApplicationContext(),"Se actualizo corectamente",Toast.LENGTH_LONG).show();
        db.close();
    }
}
